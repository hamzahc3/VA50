import pygame

pygame.init()
# Set up the game window (even if you don't need it yet)
window_width, window_height = 800, 600
window = pygame.display.set_mode((window_width, window_height))

# Load the sprite sheet
sprite_sheet = pygame.image.load('characters/Panda.png').convert_alpha()

# Get the dimensions of the sprite sheet
sheet_width, sheet_height = sprite_sheet.get_size()

# Define the number of frames in each row and the number of rows
num_columns = 8  # Number of frames per row
num_rows = 15    # Number of rows

# Calculate the frame width and height
frame_width = sheet_width // num_columns
frame_height = sheet_height // num_rows

print(f'Frame size: {frame_width}x{frame_height}')
# Quit Pygame when you're done
pygame.quit()