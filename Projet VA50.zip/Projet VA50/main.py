import pygame
import cv2
import matplotlib.pyplot as plt
import numpy as np


image = cv2.imread("imgflip2.png")

imgSRC = cv2.imread("original-af39debcf3fe1c9fd1fc5c73ac7ef67c copie.png")


plt.imshow(imgSRC)
plt.show()


# Convert to grayscale
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply Gaussian blur to reduce noise
blurred = cv2.GaussianBlur(gray, (5, 5), 0)

# Apply binary thresholding
_, thresh = cv2.threshold(blurred, 240, 255, cv2.THRESH_BINARY_INV)  # Adjust the threshold value

# Find contours
contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# Create a copy of the image to draw the straight line contours
line_contour_image = image.copy()

# Create an empty mask
mask = np.zeros_like(image)

table_corners = []

# Filter contours to keep the table and approximate to straight lines
for contour in contours:
    if cv2.contourArea(contour) > 350:  # Adjust this value based on your table size
        # Approximate the contour to a polygon
        epsilon = 0.01 * cv2.arcLength(contour, True)  # Adjust the epsilon value for precision
        approx = cv2.approxPolyDP(contour, epsilon, True)
        
        # Draw the approximated contour (straight lines) on the image
        cv2.drawContours(line_contour_image, [approx], -1, (0, 255, 0), 3)  # Green color
        
        table_corners.append(approx.reshape(-1, 2))  # Store the corners
        print("Corners of the table:", approx.reshape(-1, 2))

        # Use the mask to isolate the table
        cv2.drawContours(mask, [approx], -1, (255, 255, 255), thickness=cv2.FILLED)

# Isolate the table
isolated_table = cv2.bitwise_and(image, mask)


# cv2.imshow('Original Image', image)
# cv2.imshow('Threshold', thresh)
# cv2.imshow('Straight Line Contours', line_contour_image)  # Display the image with straight line contours
# cv2.imshow('Mask', mask)
# cv2.imshow('Isolated Table', isolated_table)
# cv2.waitKey(0)
# cv2.destroyAllWindows()

if table_corners:
    # Assuming you want to work with the first detected table's corners
    corners = table_corners[0]

    # Convert corners to float32 type
    corners = corners.astype(np.float32)
    
    # Get the width and height of the original image
    h, w = imgSRC.shape[:2]

    # Define the destination points for the Z-axis flip effect using the original corners
    dst_points = np.float32([[0, 0], [0, h], [w, h], [w, 0]])  # Destination points remain the same

    # Calculate the homography matrix
    matrix = cv2.getPerspectiveTransform(corners, dst_points)

    # Apply the homography to get the transformed image
    flipped_image = cv2.warpPerspective(image, matrix, (w, h))

    # Show the results
    cv2.imshow('Original Image', imgSRC)
    cv2.imshow('Square Contours', line_contour_image)  # Display the image with square contours
    cv2.imshow('Flipped Image', flipped_image)  # Display the transformed image
else:
    print("No table corners detected.")

cv2.waitKey(0)
cv2.destroyAllWindows()











def compare_regions(original_image, comparison_image, regions):
    

    
    for (x, y, w, h) in regions_of_interest:
        # Extract regions of interest from the images
        roi_original = original_image[y:y+h, x:x+w]
        roi_comparison = comparison_image[y:y+h, x:x+w]

        # Lower the quality of the original region
        # Downscale the original ROI
        roi_original_low_quality = cv2.resize(roi_original, (w // 4, h // 4), interpolation=cv2.INTER_LINEAR)
        # Upscale back to the original size
        roi_original_low_quality = cv2.resize(roi_original_low_quality, (w, h), interpolation=cv2.INTER_LINEAR)

        # Check if sizes are the same
        if roi_original_low_quality.shape != roi_comparison.shape:
            print(f"Size mismatch in ROI at ({x}, {y}): Original size {roi_original_low_quality.shape}, Comparison size {roi_comparison.shape}")
            continue

        # Calculate the absolute difference between the two ROIs
        difference = cv2.absdiff(roi_original_low_quality, roi_comparison)

        # Convert the difference to grayscale
        diff_gray = cv2.cvtColor(difference, cv2.COLOR_BGR2GRAY)

        # Threshold the difference image to highlight changes
        _, thresh_diff = cv2.threshold(diff_gray, 30, 255, cv2.THRESH_BINARY)

        # Find contours in the thresholded difference image
        contours, _ = cv2.findContours(thresh_diff, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Create a copy of the original ROI to draw differences
        difference_drawn = roi_original.copy()

        # Draw contours on the original ROI
        for contour in contours:
            if cv2.contourArea(contour) > 100:  # Filter small areas
                cv2.drawContours(difference_drawn, [contour], -1, (0, 0, 255), 2)  # Red color

        print("Diff", contour)
        # Show results for the current ROI
        cv2.imshow(f'Difference Image - ROI {x},{y}', difference_drawn)

    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Define specific regions to compare (x, y, width, height)
regions_of_interest = [
    (524, 276, 170, 170), 
    (528, 636, 170, 170), 
    (1020, 474, 170, 170),  
    (1252, 818, 170, 170),  
    (854, 808, 170, 170),
    (2097, 544, 170, 170),
    (1756, 1154, 170, 170),

]

# Call the function with paths to the original and comparison images
compare_regions(imgSRC, flipped_image, regions_of_interest)