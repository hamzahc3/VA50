import pygame
import sys
from PIL import Image

from matplotlib import pyplot as plt

# # Load the image using Pillow
# img = Image.open("original-af39debcf3fe1c9fd1fc5c73ac7ef67c.png")

# # Resize the image
# img = img.resize((1000, 565), Image.LANCZOS)  # Use LANCZOS for high-quality resizing

# # Convert the image back to a format suitable for Matplotlib
# img_array = plt.imread("original-af39debcf3fe1c9fd1fc5c73ac7ef67c.png")  # Read image again for display

# # Display the image using Matplotlib
# plt.imshow(img)
# plt.show()



# exit()





import pygame
import sys
from PIL import Image

# Initialize Pygame
pygame.init()

# Set up the game window
window_width, window_height = 1000, 565
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Sprite Sheet Animation with Path and Movement')

# Load the background image using Pillow for smooth scaling
background_image_pil = Image.open('original-af39debcf3fe1c9fd1fc5c73ac7ef67c.png')

# Get the original size of the background image
bg_width, bg_height = background_image_pil.size

# Calculate the scaling factor to contain the background
scale_width = window_width / bg_width
scale_height = window_height / bg_height
scale_factor = min(scale_width, scale_height)  # Use the smaller scaling factor to contain

# New dimensions after scaling (keeping aspect ratio)
new_bg_width = int(bg_width * scale_factor)
new_bg_height = int(bg_height * scale_factor)

# Resize the background using high-quality resampling
background_image_pil = background_image_pil.resize((new_bg_width, new_bg_height), Image.LANCZOS)

# Convert the Pillow image back to Pygame format
background_image = pygame.image.fromstring(
    background_image_pil.tobytes(), 
    background_image_pil.size, 
    background_image_pil.mode
)

# Calculate the position to center the background in the window
bg_x = (window_width - new_bg_width) // 2
bg_y = (window_height - new_bg_height) // 2

# Load the sprite sheet
sprite_sheet = pygame.image.load('characters/Panda.png').convert_alpha()

# Define the size of each frame in the sprite sheet
frame_width, frame_height = 48, 48  # Change these to the correct frame size
num_frames = 8  # Number of frames in the third row

# Function to extract a specific frame from a specific row in the sprite sheet
def get_frame(sheet, frame_num, width, height, row_num):
    """Extract a frame from the given row (row_num) and column (frame_num)"""
    frame = pygame.Surface((width, height), pygame.SRCALPHA)
    frame.blit(sheet, (0, 0), (frame_num * width, row_num * height, width, height))
    return frame

# Character's initial position
character_x, character_y = -20, 260
character_speed = 5
frame_index = 0
frame_delay = 5  # Delay to control animation speed
frame_counter = 0

# Define the path as a list of points
path_points = [(-20, 260), (154, 260), (154, 209), (345, 209), (345, 141), (724, 141), (724, 209), (818, 209), (818, 408), (341, 408), (341, 566)]
path_index = 0
path_speed = 3  # Speed at which to follow the path

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Get pressed keys for movement
    keys = pygame.key.get_pressed()
    moving = False

    # Move character based on arrow keys
    if keys[pygame.K_LEFT]:
        character_x -= character_speed
        moving = True
    if keys[pygame.K_RIGHT]:
        character_x += character_speed
        moving = True
    if keys[pygame.K_UP]:
        character_y -= character_speed
        moving = True
    if keys[pygame.K_DOWN]:
        character_y += character_speed
        moving = True

    # Move along the predefined path
    if path_index < len(path_points):
        target_x, target_y = path_points[path_index]

        # Move character towards the next point in the path
        if abs(character_x - target_x) < path_speed:  # Close enough to target_x
            character_x = target_x  # Snap to target_x
            if abs(character_y - target_y) < path_speed:  # Close enough to target_y
                character_y = target_y  # Snap to target_y
                path_index += 1  # Move to the next point in the path
            else:
                # Move vertically towards target_y
                if character_y < target_y:
                    character_y += path_speed
                elif character_y > target_y:
                    character_y -= path_speed
        else:
            # Move horizontally towards target_x
            if character_x < target_x:
                character_x += path_speed
            elif character_x > target_x:
                character_x -= path_speed

    # Update frame index for animation (if moving)
    if moving or path_index < len(path_points):
        frame_counter += 1
        if frame_counter >= frame_delay:
            frame_index = (frame_index + 1) % num_frames
            frame_counter = 0
    else:
        frame_index = 0  # Reset to the idle frame when not moving

    # Clear screen and draw the high-quality scaled background centered
    window.fill((0, 0, 0))  # Clear with a black background
    window.blit(background_image, (bg_x, bg_y))  # Center the scaled background

    # Draw the path (optional, uncomment if you want to see the path)
    if len(path_points) > 1:
        pygame.draw.lines(window, (255, 0, 0), False, path_points, 3)  # Draw the path in red

    # Get the current frame from the third row (row index = 2)
    current_frame = get_frame(sprite_sheet, frame_index, frame_width, frame_height, row_num=2)

    # Draw character's current frame on the screen
    window.blit(current_frame, (character_x, character_y))

    # Update the display
    pygame.display.flip()

    # Limit the frame rate
    pygame.time.Clock().tick(30)

# Quit Pygame
pygame.quit()
sys.exit()







































import pygame
import sys
from PIL import Image

# Initialize Pygame
pygame.init()

# Set up the game window
window_width, window_height = 1000, 565
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Sprite Sheet Animation with Path')

# Load the background image using Pillow for smooth scaling
background_image_pil = Image.open('original-af39debcf3fe1c9fd1fc5c73ac7ef67c.png')
bg_width, bg_height = background_image_pil.size

# Resize the background image
background_image_pil = background_image_pil.resize((window_width, window_height), Image.LANCZOS)
background_image = pygame.image.fromstring(background_image_pil.tobytes(), background_image_pil.size, background_image_pil.mode)
bg_x = 0
bg_y = 0

# Load the sprite sheet
sprite_sheet = pygame.image.load('characters/Panda.png').convert_alpha()

# Define the size of each frame in the sprite sheet
frame_width, frame_height = 48, 48  # Change these to the correct frame size
num_frames = 8  # Number of frames in the third row

# Function to extract a specific frame from a specific row in the sprite sheet
def get_frame(sheet, frame_num, width, height, row_num):
    """Extract a frame from the given row (row_num) and column (frame_num)"""
    frame = pygame.Surface((width, height), pygame.SRCALPHA)
    frame.blit(sheet, (0, 0), (frame_num * width, row_num * height, width, height))
    return frame

# Character's initial position
character_x, character_y = -100, 290
character_speed = 5
frame_index = 0
frame_delay = 5
frame_counter = 0

# Define the path as a list of points
path_points = [(-100, 290), (160, 290), (160, 219), (345, 219), (345, 141)]
path_index = 0
path_speed = 3  # Speed at which to follow the path

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Clear screen and draw the high-quality scaled background centered
    window.fill((0, 0, 0))  # Clear with a black background
    window.blit(background_image, (bg_x, bg_y))  # Center the scaled background

    # Draw the path
    if len(path_points) > 1:
        pygame.draw.lines(window, (255, 0, 0), False, path_points, 3)  # Draw the path in red

    # Move the character along the path
    if path_index < len(path_points):
        target_x, target_y = path_points[path_index]

        # Move character towards the next point in the path
        if abs(character_x - target_x) < path_speed:  # Close enough to target_x
            character_x = target_x  # Snap to target_x
            if abs(character_y - target_y) < path_speed:  # Close enough to target_y
                character_y = target_y  # Snap to target_y
                path_index += 1  # Move to the next point in the path
            else:
                # Move vertically towards target_y
                if character_y < target_y:
                    character_y += path_speed
                elif character_y > target_y:
                    character_y -= path_speed
        else:
            # Move horizontally towards target_x
            if character_x < target_x:
                character_x += path_speed
            elif character_x > target_x:
                character_x -= path_speed

    # Get the current frame from the third row (row index = 2)
    current_frame = get_frame(sprite_sheet, frame_index, frame_width, frame_height, row_num=2)

    # Draw character's current frame on the screen
    window.blit(current_frame, (character_x, character_y))

    # Update the display
    pygame.display.flip()

    # Limit the frame rate
    pygame.time.Clock().tick(30)

# Quit Pygame
pygame.quit()
sys.exit()









import pygame
import sys
from PIL import Image

# Initialize Pygame
pygame.init()

# Set up the game window
window_width, window_height = 1000, 565
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption('Sprite Sheet Animation with High-Quality Contained Background')

# Load the background image using Pillow for smooth scaling
background_image_pil = Image.open('original-af39debcf3fe1c9fd1fc5c73ac7ef67c.png')

# Get the original size of the background image
bg_width, bg_height = background_image_pil.size

# Calculate the scaling factor to contain the background
scale_width = window_width / bg_width
scale_height = window_height / bg_height
scale_factor = min(scale_width, scale_height)  # Use the smaller scaling factor to contain

# New dimensions after scaling (keeping aspect ratio)
new_bg_width = int(bg_width * scale_factor)
new_bg_height = int(bg_height * scale_factor)

# Resize the background using high-quality resampling
background_image_pil = background_image_pil.resize((new_bg_width, new_bg_height), Image.LANCZOS)

# Convert the Pillow image back to Pygame format
background_image = pygame.image.fromstring(
    background_image_pil.tobytes(), 
    background_image_pil.size, 
    background_image_pil.mode
)

# Calculate the position to center the background in the window
bg_x = (window_width - new_bg_width) // 2
bg_y = (window_height - new_bg_height) // 2

# Load the sprite sheet
sprite_sheet = pygame.image.load('characters/Panda.png').convert_alpha()

# Define the size of each frame in the sprite sheet
frame_width, frame_height = 48, 48  # Change these to the correct frame size
num_frames = 8  # Number of frames in the third row

# Function to extract a specific frame from a specific row in the sprite sheet
def get_frame(sheet, frame_num, width, height, row_num):
    """Extract a frame from the given row (row_num) and column (frame_num)"""
    # Create a new surface for the frame
    frame = pygame.Surface((width, height), pygame.SRCALPHA)
    # Blit the specific frame from the sheet based on row and column
    frame.blit(sheet, (0, 0), (frame_num * width, row_num * height, width, height))  
    return frame

# Character's initial position
character_x, character_y = 100, 100
character_speed = 5

# Current animation frame index
frame_index = 0
frame_delay = 5  # Delay to control animation speed
frame_counter = 0

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Get pressed keys for movement
    keys = pygame.key.get_pressed()
    moving = False

    if keys[pygame.K_LEFT]:
        character_x -= character_speed
        moving = True
    if keys[pygame.K_RIGHT]:
        character_x += character_speed
        moving = True
    if keys[pygame.K_UP]:
        character_y -= character_speed
        moving = True
    if keys[pygame.K_DOWN]:
        character_y += character_speed
        moving = True

    # Update frame index for animation (if moving)
    if moving:
        frame_counter += 1
        if frame_counter >= frame_delay:
            frame_index = (frame_index + 1) % num_frames
            frame_counter = 0
    else:
        frame_index = 0  # Reset to the idle frame when not moving

    # Clear screen and draw the high-quality scaled background centered
    window.fill((0, 0, 0))  # Clear with a black background
    window.blit(background_image, (bg_x, bg_y))  # Center the scaled background

    # Get the current frame from the third row (row index = 2)
    current_frame = get_frame(sprite_sheet, frame_index, frame_width, frame_height, row_num=2)

    # Draw character's current frame on the screen
    window.blit(current_frame, (character_x, character_y))

    # Update the display
    pygame.display.flip()

    # Limit the frame rate
    pygame.time.Clock().tick(30)

# Quit Pygame
pygame.quit()
sys.exit()
