
import cv2
import numpy as np


def compare_regions(original_image_path, comparison_image_path, regions):
    # Load the original and comparison images
    original_image = cv2.imread(original_image_path)
    comparison_image = cv2.imread(comparison_image_path)

    # Create a copy of the original image to draw differences
    difference_image = original_image.copy()

    for idx, (x, y, w, h) in enumerate(regions):
        # Extract the regions from both images
        roi_original = original_image[y:y+h, x:x+w]
        roi_comparison = comparison_image[y:y+h, x:x+w]

        # Compute the absolute difference between the two regions
        diff = cv2.absdiff(roi_original, roi_comparison)

        # Convert the difference to grayscale
        diff_gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)

        # Threshold the difference to highlight changes
        _, thresh_diff = cv2.threshold(diff_gray, 30, 255, cv2.THRESH_BINARY)  # Adjust the threshold value

        # Check if there are any significant differences
        if np.count_nonzero(thresh_diff) > 0:  # If there are any non-zero pixels in the thresholded difference
            print(f"Difference detected in region {idx + 1} at (x: {x}, y: {y})")
            # Draw a rectangle around the region of difference in the difference image
            cv2.rectangle(difference_image, (x, y), (x + w, y + h), (0, 0, 255), 2)  # Red rectangle

    # Show the results
    cv2.imshow('Original Image', original_image)
    cv2.imshow('Comparison Image', comparison_image)
    cv2.imshow('Difference Image', difference_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Define specific regions to compare (x, y, width, height)
regions_of_interest = [
    (50, 50, 200, 200),  # Example region 1
    (300, 50, 200, 200), # Example region 2
    (50, 300, 200, 200)  # Example region 3
]

# Call the function with paths to the original and comparison images
compare_regions("original-af39debcf3fe1c9fd1fc5c73ac7ef67c copie.png", "imgflip copie.png", regions_of_interest)